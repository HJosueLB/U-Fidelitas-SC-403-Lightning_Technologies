package com.LightningTech.service;

import com.LightningTech.domain.Servicios;
import java.util.List;

public interface ServiciosService {
    
    List<Servicios> listarTodos();
    
}
