package Codigo.LT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightningTechnologiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
