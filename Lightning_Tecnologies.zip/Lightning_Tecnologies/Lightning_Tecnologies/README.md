# U Fidelitas SC-403 Lightning_Technologies

Proyecto grupal #5 | Desarrollo de Aplicaciones Web y Patrones | Campus Virtual 2024 | Primer Cuatrimestre | J (6pm-9pm)
--------------------------------------------------------------------
Descripción: Página web de comercio de equipos de cómputo y componentes, donde se podrá gestionar la compra y la solicitud adicional de cotización de servicios de mantenimientos preventivos y correctivos, así como también consultas para el emprendimiento Lightning Technologies
